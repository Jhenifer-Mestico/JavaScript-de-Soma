var y =20;
var x = 5;
document.writeln(x+y);
/*soma OK*/